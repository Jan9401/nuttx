/*
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef RPMSG_RPC_DEMO_H
#define RPMSG_RPC_DEMO_H

#define RPMSG_SERVICE_NAME         "rpmsg-openamp-demo-channel"

#endif /* RPMSG_RPC_DEMO_H */
