# Libmetal build check docker action

This action test builds for a specified target.

## Inputs

### `target`

**Required** the build target. Default `"linux"`.
The supported targets are:
  linux
  generic arm
  freertos
  zephyr


## Example usage

uses: ./.github/actions/build_ci
with:
  target: freertos